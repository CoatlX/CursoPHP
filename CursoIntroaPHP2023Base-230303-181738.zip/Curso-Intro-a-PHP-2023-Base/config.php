<?php 
// Inicializa la sesión
session_start();

// Se cargan las funciones
require_once "funciones.php";