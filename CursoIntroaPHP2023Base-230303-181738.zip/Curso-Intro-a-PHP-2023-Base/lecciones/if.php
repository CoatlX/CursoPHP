<?php 

$a = 5;
$b = 10;
$c = 'pancho';
$d = true;

// If
if ($a > $b) {
  echo 'a es mayor que b';
} 

// Else
if ($a > $b) {
  echo 'a es mayor que b';
} else {
  echo 'b es mayor que a';
}

// Elseif
if ($a > $b) {
  echo 'a es mayor que b';
} elseif ($a == $b) {
  echo 'a es igual que b';
} else {
  echo 'b es mayor que a';
}