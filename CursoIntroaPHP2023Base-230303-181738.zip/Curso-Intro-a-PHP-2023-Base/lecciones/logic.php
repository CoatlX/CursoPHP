<?php 

$correcto = 123;

if ($correcto == false) {
  echo '$correcto es igual a false.';
} else {
  echo '$correcto es igual a true.';
}