<?php 
# incluyendo.php

require_once 'header.php';
require_once 'footer.php';

echo "Aquí estoy, sigo ejecutando el código.\n";
echo '$a es igual a: ' . $a . "\n";
echo '$b es igual a: ' . $b . "\n";
