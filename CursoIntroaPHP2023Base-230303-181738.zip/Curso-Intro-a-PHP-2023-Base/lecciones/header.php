<?php 
# header.php

echo "Vengo desde el archivo header.php.\n";
// se define la variable $a
$a = 10;
