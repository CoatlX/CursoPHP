<?php 
// Constantes Mágicas

// Ejemplos prácticos
echo __DIR__ . '<br>';

echo __FILE__ . '<br>';

echo __LINE__ . '<br>';

echo __CLASS__ . '<br>';

echo __FUNCTION__ . '<br>';

echo __TRAIT__ . '<br>';