<?php 
# footer.php

echo "Vengo desde el archivo footer.php.\n";
// se define la variable $b
$b = 20;
